## v1.1.2:

* [COOK-2334] - Add ability to set locale on Ubuntu

## v1.1.0:

* [COOK-2104] - allow specifying architectures for repos

## v1.0.0:

* [COOK-1774] - Add attribute to enable/disable including source apt
  repositories

## v0.99.0

* Current public release
